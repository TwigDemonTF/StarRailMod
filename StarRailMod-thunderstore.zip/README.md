# StarRailMod
 a mod for touhou lost branch of legend that i enjoy making
